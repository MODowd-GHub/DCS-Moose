--Start the RedMANTIS
redmantis = MANTIS:New("redmantis","Red SAM","Red EWR","Red HQ","red",true,"Red Awacs")
redmantis:SetAutoRelocate(true, true) -- make HQ and EWR relocatable, if they are actually mobile in DCS!
redmantis:SetAdvancedMode(true, 100) -- switch on advanced mode - detection will slow down or die if HQ and EWR die
redmantis:SetSAMRange(90)
--redmantis:SetSAMRadius(30000)
--redmantis:Debug(true)
--redmantis.verbose = true -- watch DCS.log
redmantis:Start()

--Start the dispatcher
RedRedA2ADispatcher = AI_A2A_DISPATCHER:New(redmantis.Detection)  -- use existing detection object
RedRedA2ADispatcher:SetTacticalDisplay( true )
--Set Border
RedBorder = ZONE_POLYGON:New( "CCCP Border", GROUP:FindByName( "Red Border" ) )
RedRedA2ADispatcher:SetBorderZone( RedBorder )
RedRedA2ADispatcher:SetEngageRadius( 150000 )
--RedRedA2ADispatcher:SetGciRadius( 100000 )

RedRedA2ADispatcher:SetSquadron( "BandarGCI", AIRBASE.PersianGulf.Bandar_Abbas_Intl, { "SQ IRI F1", "SQ IRI F4" }, 2 )
RedRedA2ADispatcher:SetSquadronGci( "BandarGCI", 800, 1200 )
RedRedA2ADispatcher:SetSquadronOverhead("BandarGCI", 1 )
RedRedA2ADispatcher:SetSquadronGrouping( "BandarGCI", 2 )
RedRedA2ADispatcher:SetSquadronTakeoffFromRunway( "BandarGCI" )

RedRedA2ADispatcher:SetSquadron( "QeshmGCI", AIRBASE.PersianGulf.Qeshm_Island, { "SQ IRI F5" }, 2 )
RedRedA2ADispatcher:SetSquadronGci( "QeshmGCI", 800, 1200 )
RedRedA2ADispatcher:SetSquadronOverhead("QeshmGCI", 1 )
RedRedA2ADispatcher:SetSquadronGrouping( "QeshmGCI", 2 )
RedRedA2ADispatcher:SetSquadronTakeoffFromRunway( "QeshmGCI" )

RedRedA2ADispatcher:SetSquadron( "KishCAP", AIRBASE.PersianGulf.Kish_International_Airport, { "SQ IRI MIG29" }, 4 )
RedRedA2ADispatcher:SetSquadronGci( "KishCAP", 800, 1200 )
RedRedA2ADispatcher:SetSquadronOverhead("KishCAP", 1 )
RedRedA2ADispatcher:SetSquadronGrouping( "KishCAP", 2 )
RedRedA2ADispatcher:SetSquadronTakeoffFromRunway( "KishCAP" )

RedRedA2ADispatcher:SetSquadron( "KishCAP", AIRBASE.PersianGulf.Kish_International_Airport, { "SQ IRI F4" }, 4 )
--RedRedA2ADispatcher:SetSquadronGci( "KishCAP", 800, 1200 )
RedRedA2ADispatcher:SetSquadronOverhead("KishCAP", 1 )
RedRedA2ADispatcher:SetSquadronGrouping( "KishCAP", 2 )
RedRedA2ADispatcher:SetSquadronTakeoffFromParkingHot( "KishCAP" )

RedRedA2ADispatcher:SetSquadron( "HavadaryaCAP", AIRBASE.PersianGulf.Havadarya, { "SQ IRI MIG29" }, 4 )
--RedRedA2ADispatcher:SetSquadronGci( "HavadaryaCAP", 800, 1200 )
RedRedA2ADispatcher:SetSquadronOverhead("HavadaryaCAP", 1 )
RedRedA2ADispatcher:SetSquadronGrouping( "HavadaryaCAP", 2 )
RedRedA2ADispatcher:SetSquadronTakeoffFromParkingHot( "HavadaryaCAP" )

RedRedA2ADispatcher:SetSquadron( "JaskCAP", AIRBASE.PersianGulf.Bandar_e_Jask_airfield, { "SQ IRI F1-1" }, 4 )
--RedRedA2ADispatcher:SetSquadronGci( "JaskCAP", 800, 1200 )
RedRedA2ADispatcher:SetSquadronOverhead("JaskCAP", 1 )
RedRedA2ADispatcher:SetSquadronGrouping( "JaskCAP", 2 )
RedRedA2ADispatcher:SetSquadronTakeoffFromParkingHot( "JaskCAP" )

RedCAPZone1 = ZONE:New( "RedCapZone1")
RedA2ADispatcher:SetSquadronCap( "HavadaryaCAP", RedCAPZone1, 4000, 8000, 600, 800, 800, 1200, "BARO" )
RedA2ADispatcher:SetSquadronCapInterval( "HavadaryaCAP", 1, 30, 300, 1 )

RedCAPZone2 = ZONE:New( "RedCapZone2")
RedRedA2ADispatcher:SetSquadronCap( "KishCAP", B1, 4000, 8000, 600, 800, 800, 1200, "RADIO" )
RedRedA2ADispatcher:SetSquadronCapInterval( "KishCAP", 1, 30, 300, 1 )

RedCAPZone3 = ZONE:New( "RedCapZone3")
RedA2ADispatcher:SetSquadronCap( "JaskCAP", RedCAPZone3, 4000, 8000, 600, 800, 800, 1200, "BARO" )
RedA2ADispatcher:SetSquadronCapInterval( "JaskCAP", 1, 30, 300, 1 )


